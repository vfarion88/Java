
package appveiculo;

public class AppVeiculo {

    public static void main(String[] args) {
        TelaVeiculo a = new TelaVeiculo();
        
        a.menu();
    }
    
}
