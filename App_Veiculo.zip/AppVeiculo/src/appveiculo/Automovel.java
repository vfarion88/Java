package appveiculo;

public class Automovel extends Veiculo{
    private int cv;
    
    public Automovel(int renavam, String placa, int ano, String marca, String modelo,String tipo, int cv) {
        super(renavam, placa, ano, marca, modelo,tipo);
        this.cv = cv;
    }

    public int getCv() {
        return cv;
    }

    public void setCv(int cv) {
        this.cv = cv;
    }
    
}
