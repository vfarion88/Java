
package appveiculo;

public class Caminhao extends Veiculo{
    private int peso;
    
    public Caminhao(int renavam, String placa, int ano, String marca, String modelo,String tipo, int peso) {
        super(renavam, placa, ano, marca, modelo, tipo);
        this.peso = peso;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }
    
}
