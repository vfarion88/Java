
package appveiculo;

import java.util.ArrayList;
import java.util.Scanner;

public class ControlarVeiculo {
    private ArrayList<Veiculo> cadastro = new ArrayList<Veiculo>();
        
    public void inserir(Veiculo m){
         cadastro.add(m);
         
    }    
    public void mostrar(){
        for (int i = 0; i < cadastro.size(); i++) {
		System.out.println("Renavam: " + cadastro.get(i).getRenavam());
                System.out.println("Placa: " + cadastro.get(i).getPlaca());
                System.out.println("Ano: " + cadastro.get(i).getAno());
                System.out.println("Marca: " + cadastro.get(i).getMarca());
                System.out.println("Modelo: " + cadastro.get(i).getModelo());
               
                switch (cadastro.get(i).getTipo()){
                    case "Automovel":
                        Automovel temp = (Automovel)cadastro.get(i);
                         System.out.println("Modelo: " + temp.getCv());
                    case "Motocicleta":
                        Motocicleta temp1 = (Motocicleta)cadastro.get(i);
                        System.out.println("Modelo: " + temp1.getCilindrada());
                    case "Caminhao":
                        Caminhao temp2 = (Caminhao)cadastro.get(i);
                         System.out.println("Modelo: " + temp2.getPeso());    
                }
	}
    }
    public void pesquisar(String placa){
        for (int i = 0; i < cadastro.size(); i++) {
            if (placa == null ? cadastro.get(i).getPlaca() == null : placa.equals(cadastro.get(i).getPlaca())){
                 System.out.println("Placa cadastrada na nossa base de dados !!!");
            }else
                System.out.println("Placa não cadastrada!!!");
	}
        
    }
}
