
package appveiculo;

public class Motocicleta extends Veiculo {
    private int cilindrada;
        
    public Motocicleta(int renavam, String placa, int ano, String marca, String modelo, String tipo,int cilindrada) {
        super(renavam, placa, ano, marca, modelo,tipo);
        this.cilindrada = cilindrada;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }
    
}
