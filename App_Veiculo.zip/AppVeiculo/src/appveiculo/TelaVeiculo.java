
package appveiculo;

import java.util.Scanner;

public class TelaVeiculo {
    
    private ControlarVeiculo controlar;
    
    public TelaVeiculo(){
        controlar = new ControlarVeiculo();
    }
    
    public void carregarMotocicleta(){
                //Solicitar dados da pessoa
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Digite o Renavam: ");
		int renavam = scan.nextInt();
		
		System.out.println("Digite a Placa: ");
		String placa = scan.next();
		
		System.out.println("Digite o Ano: ");
		int ano = scan.nextInt();
		
		System.out.println("Digite a Marca: ");
		String marca = scan.next();
		
		System.out.println("Digite o Modelo: ");
		String modelo = scan.next();
                
                System.out.println("Digite a Cilindrada: ");
		int cilindrada = scan.nextInt();
		
		//Instanciar um objeto Pessoa
		Motocicleta m = new Motocicleta(renavam, placa, ano, marca, modelo,"Motocicleta", cilindrada);
                
                controlar.inserir(m);
    }
    public void carregarAutomovel(){
                //Solicitar dados da pessoa
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Digite o Renavam: ");
		int renavam = scan.nextInt();
		
		System.out.println("Digite a Placa: ");
		String placa = scan.next();
		
		System.out.println("Digite o Ano: ");
		int ano = scan.nextInt();
		
		System.out.println("Digite a Marca: ");
		String marca = scan.next();
		
		System.out.println("Digite o Modelo: ");
		String modelo = scan.next();
                
                System.out.println("Digite a CV: ");
		int cv = scan.nextInt();
		
		//Instanciar um objeto Pessoa
		Automovel a = new Automovel(renavam, placa, ano, marca, modelo,"Automovel", cv);
                
                controlar.inserir(a);
    }
    public void carregarCaminhao(){
                //Solicitar dados da pessoa
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Digite o Renavam: ");
		int renavam = scan.nextInt();
		
		System.out.println("Digite a Placa: ");
		String placa = scan.next();
		
		System.out.println("Digite o Ano: ");
		int ano = scan.nextInt();
		
		System.out.println("Digite a Marca: ");
		String marca = scan.next();
		
		System.out.println("Digite o Modelo: ");
		String modelo = scan.next();
                
                System.out.println("Digite a Peso: ");
		int peso = scan.nextInt();
		
		//Instanciar um objeto Pessoa
		Caminhao c = new Caminhao(renavam, placa, ano, marca, modelo,"Caminhão", peso);
                
                controlar.inserir(c);
    }
    public void mostrar(){
        controlar.mostrar();
    }
    public void pesquisar(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Digite a Placa a ser digitada");
        String placa = scan.next();
        controlar.pesquisar(placa);
    }
    public void menu(){
            Scanner scan = new Scanner(System.in);
       
            int aux = 0;
        
                while(aux != 6){
                        
			System.out.println("Selecione uma Opção:");
			System.out.println("1 - Inserir Automovel ");
			System.out.println("2 - Inserir Caminhão");
			System.out.println("3 - Inserir Motocicleta");
			System.out.println("4 - Procurar por Placa cadastrada");
			System.out.println("5 - Listar Todos");
                        System.out.println("6 - sair");
                        aux = scan.nextInt();
			
			switch(aux){
				case 1: 
                                        carregarAutomovel();
                                       break;
				case 2:
					carregarCaminhao();
					break;
				case 3:
					carregarMotocicleta();
					break;
				case 4:
					pesquisar();
					break;
				case 5:
                                       mostrar();
                                        break;
                                case 6:        
					System.out.println("Saindo...");
			}
                      
		}
        }
    }
    
    
    

