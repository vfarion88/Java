
package AlunoApp;

import cadastroaluno.AlunoStatus;
import java.util.Scanner;

public class AlunoApp {

    public static void main(String[] args) {
        AlunoStatus status = new AlunoStatus();
        
	Scanner scan = new Scanner(System.in);
        
        int aux = 0;
        
        while(aux != 5){
			System.out.println("Selecione uma Opção:");
			System.out.println("1 - Inserir Aluno ");
			System.out.println("2 - Alterar Aluno");
			System.out.println("3 - Excluir");
			System.out.println("4 - Mostrar Aluno");
			System.out.println("5 - Sair");
			
			aux = scan.nextInt();
			
			switch(aux){
				case 1: 
					status.cadastrarAluno();
                                       break;
				case 2:
					status.alterar();
					break;
				case 3:
					status.excluirAluno();
					break;
				case 4:
					status.imprimirAluno();
					break;
				case 5:
					System.out.println("Saindo...");
			}
		}
    }
    
}
