
package AlunoApp;

import cadastroaluno.Aluno;

public class ShowAluno {
    private Aluno a;

    public ShowAluno(Aluno a) {
        this.a = a;
    }

    ShowAluno() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Aluno getA() {
        return a;
    }

    public void setA(Aluno a) {
        this.a = a;
    }
    
    public void showAluno(){
        System.out.println("Nome: " + a.getNome());
        System.out.println("Cpf: "+ a.getCpf());
        System.out.println("RA: " + a.getRa());
        System.out.println("Email: " + a.getEmail());
        System.out.println("Telefone: " + a.getTel());
        System.out.println("Data de nascimento: " + a.getDataNasc());
    }
    
}
