
package cadastroaluno;

public class Aluno {
    
    private int cpf;
    private String nome;
    private int ra;
    private String email;
    private int tel;
    boolean status = true;
    private String dataNasc;

    public Aluno(int cpf, String nome, int ra, String email, int tel, String dataNasc) {
        this.cpf = cpf;
        this.nome = nome;
        this.ra = ra;
        this.email = email;
        this.tel = tel;
        this.dataNasc = dataNasc;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getRa() {
        return ra;
    }

    public void setRa(int ra) {
        this.ra = ra;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getTel() {
        return tel;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(String dataNasc) {
        this.dataNasc = dataNasc;
    }
    
    
    
    
}
