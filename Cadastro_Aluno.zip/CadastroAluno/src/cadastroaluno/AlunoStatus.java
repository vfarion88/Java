
package cadastroaluno;

import AlunoApp.ShowAluno;
import java.util.Scanner;

public class AlunoStatus {
    private ControlarAluno control;
    
    public AlunoStatus(){
		control = new ControlarAluno();
	}
    
    public void excluirAluno(){
		//Solicitar dados da pessoa
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Excluir aluno");
		System.out.println("CPF: ");
		int cpf = scan.nextInt();
		
		Aluno a = control.pesquisar(cpf);
                control.excluir(a);
	}
    public void cadastrarAluno(){
		//Solicitar dados da pessoa
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Digite Cpf do aluno: ");
		int cpf = scan.nextInt();
		
		System.out.println("Digite o nome do Aluno: ");
		String nome = scan.next();
		
		System.out.println("Digite o R.A do aluno: ");
		int ra = scan.nextInt();
		
		System.out.println("Digite o email do aluno: ");
		String email = scan.next();
		
		System.out.println("Digite telefone do aluno: ");
		int tel = scan.nextInt();
                
                System.out.println("Digite a data de nascimento do aluno: ");
		String dataNasc = scan.next();
		
		//Instanciar um objeto Pessoa
		Aluno a = new Aluno(cpf, nome, ra, email, tel, dataNasc);
		
		//Chamar na control, o m�todo inserir
		control.inserir(a);
	}
    public void imprimirAluno(){
        
        
        Scanner scan = new Scanner(System.in);
		
		System.out.println("Mostrar Aluno");
		System.out.println("CPF: ");
		int cpf = scan.nextInt();
		
		Aluno a = control.pesquisar(cpf);
                if(a == null){
                    System.out.println("Nenhum aluno cadastrado nesse CPF!!!");
                }else{
                ShowAluno imp = new ShowAluno(a);
                imp.showAluno();
                }
    }
    public void alterar(){
                Scanner scan = new Scanner(System.in);
		
		System.out.println("Excluir aluno");
		System.out.println("CPF: ");
		int cpf = scan.nextInt();
		
		Aluno a = control.pesquisar(cpf);
                control.alterar(a);
        
    }
    
}