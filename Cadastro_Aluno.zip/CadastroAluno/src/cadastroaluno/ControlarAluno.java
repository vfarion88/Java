
package cadastroaluno;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ControlarAluno {
    //Lista de Pessoas
	private ArrayList<Aluno> lista;
        
        public ControlarAluno(){
		lista = new ArrayList<Aluno>();
	}
        public void inserir(Aluno a){
		lista.add(a);
	}
        public void exibir(){
		if(lista != null && lista.size() > 0){
			//For each.. percorrer a lista sem �ndice
			for(Aluno a : lista){
				System.out.println("Nome: " + a.getNome());
			}
		}else
			System.out.println("Lista Vazia!!!");
	}
        public void excluir(Aluno a){
		lista.remove(a);
		}
		
        public Aluno pesquisar(int cpf){
            
            for(Aluno a : lista){
			//Verificar se nome da pessoa � igual
			if(a.getCpf() == cpf){				
				//Se sim, Excluir pessoa da lista
				return a;
			}
		}
          return null;
        }
        public List<Aluno> listarAlunos(){
            return lista;
        }
        public void alterar(Aluno a){
            Scanner scan = new Scanner(System.in);
		
		System.out.println("Digite Cpf do aluno: ");
		a.setCpf(scan.nextInt());
		
		System.out.println("Digite o nome do Aluno: ");
		a.setNome(scan.next());
		
		System.out.println("Digite o R.A do aluno: ");
		a.setRa(scan.nextInt());
		
		System.out.println("Digite o email do aluno: ");
		a.setEmail(scan.next());
		
		System.out.println("Digite telefone do aluno: ");
		a.setTel(scan.nextInt());
                
                System.out.println("Digite a data de nascimento do aluno: ");
		a.setDataNasc(scan.next());
		
        }
}

