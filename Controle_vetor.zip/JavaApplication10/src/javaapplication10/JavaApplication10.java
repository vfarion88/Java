
package javaapplication10;

public class JavaApplication10 {

    public static void main(String[] args) {
        Matriz M = new Matriz(2,2);
        
      
       M.carregarMatriz();
       M.exibirMatriz();
       M.calcularSoma();
       M.calcularMedia();
       M.maior();
       M.menor();
       M.qtdPares();
       M.qtdImpares();
                    
    }
    
}
