package javaapplication10;

import java.util.Scanner;

public class Matriz {
    private int matriz[][];
	private int linhas;
	private int colunas;
	
	//Construtor que inicializa a matriz com determinado tamanho
	public Matriz(int linhas, int colunas){
		this.linhas = linhas;
		this.colunas = colunas;
		
		matriz = new int[linhas][colunas];
	}
	
	//Exibir conteudo da Matriz
	public void exibirMatriz(){
            System.out.println("Matriz digita é :");
		for(int i = 0; i < linhas; i++){
                    System.out.println("");
			for(int j = 0; j < colunas; j++){
				System.out.print(" " + matriz[i][j]);
			}
		}
                System.out.println("");
                System.out.println("");
			
	}
	
	public void carregarMatriz(){
		Scanner scan = new Scanner(System.in);
		System.out.println("*****Monte sua Matriz******");
		for(int i = 0; i < linhas; i++){
			for(int j = 0; j < colunas; j++){
				System.out.print("Linha: "+ i + " coluna: "+j+" : ");
				matriz[i][j] = scan.nextInt();
			}
		}
                System.out.println("");
	}
	
	public int calcularSoma(){
		int soma = 0;
		
		for(int i = 0; i < linhas; i++){
			for(int j = 0; j < colunas; j++){
				soma+= matriz[i][j];
			}
		}
                System.out.println("A somas dos valores da Matriz são: "+ soma);
             
		
		return soma;		
	}
	
	public float calcularMedia(){
            float soma = 0;
            float media = 0;
            float resultado = 0;
		
		for(int i = 0; i < linhas; i++){
			for(int j = 0; j < colunas; j++){
				soma+= matriz[i][j];
                                media += 1;
			}
		}
		resultado = soma/media;
		          System.out.println("A média dos valores digitados são: " + resultado);
		return resultado;	
		
	}
	
	public int maior(){
            int resultado = 0;
            int maior = matriz[0][0];
		
		for(int i = 0; i < linhas; i++){
			for(int j = 0; j < colunas; j++){
                              if(matriz[i][j] > maior){
                              maior = matriz[i][j];
                         }	
                        }
		}
		
		resultado = maior;
                System.out.println("O maior valor digitado é: "+ resultado);
		return resultado;	
		
		
	}
	
	public int menor(){
            int resultado = 0;
            int menor = matriz[0][0];
		
		for(int i = 0; i < linhas; i++){
			for(int j = 0; j < colunas; j++){
                              if(matriz[i][j] < menor){
                              menor = matriz[i][j];
                         }	
                        }
		}
		
		resultado = menor;
                System.out.println("O menor valor digitado é: "+resultado);
		return resultado;
		
	}
	
	public int qtdPares(){
            int par = 0;
            int maior = matriz[0][0];
		for(int i = 0; i < linhas; i++){
			for(int j = 0; j < colunas; j++){
                              if(matriz[i][j] % 2 ==0){
                              par +=1;
                         }	
                        }
		}
                System.out.println("A quantidade de numeros pares são: "+par);
		return par;
		
	}
	
	public int qtdImpares(){
            int impar = 0;
            	for(int i = 0; i < linhas; i++){
			for(int j = 0; j < colunas; j++){
                              if(matriz[i][j] % 2 == 1){
                              impar += 1;
                         }	
                        }
		}
		
		          System.out.println("A quantidade de numeros impares são: " + impar);
		return impar;
		
	}
      
}
