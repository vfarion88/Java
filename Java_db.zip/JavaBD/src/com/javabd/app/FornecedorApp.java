package com.javabd.app;

import java.util.List;

import com.javabd.model.Fornecedor;
import com.javabd.session.FornecedorSession;


public class FornecedorApp {

	public static void main(String[] args) {
		     //Criar e instanciar um objeto Fornecedor
			    Fornecedor f = new Fornecedor(123456, "Ford", "Focus");
				
				//Criar e instanciar um objeto FornecedorSession
				FornecedorSession session = new FornecedorSession();
				
				
				//Invocar o m�todo inserirFornecedor
				session.inserirFornecedor(f);
				
				//Invocar metodo Update
				session.alterarFornecedor(987654,"GM", "Corsa");
				
				//Invocar metodo deletar
				session.excluirFornecedor(123456);
				
		        List<Fornecedor> lista = session.listarTodos();
				
				for(Fornecedor x : lista){
					System.out.println("Renavam: " + x.getRenavam());
					System.out.println("Marca do Veiculo: " + x.getMarcaVeiculo());
					System.out.println("Nome do veiculo: " + x.getNomeVeiculo());
				}

	}

}
