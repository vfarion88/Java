package com.javabd.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.io.IOException;

import com.javabd.db.ConnectDB;

public class DAO {
	protected ConnectDB db;
	protected Connection connection;
	
	public DAO() {
		//Inicializar ConnectDB
		db = new ConnectDB();
	}
	public void conectar() throws Exception {
		if(connection == null)
			connection = db.getConnection();
	}
	public void desconectar() throws Exception {
		if(connection != null)
			connection.close();
	}
}
