package com.javabd.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.javabd.model.Fornecedor;

public class FornecedorDAO extends DAO{
	private String SQL_INSERT = "INSERT INTO VEICULOTB(renavam, marcaveiculo, nomeveiculo) values(?, ?, ?);";
	private String SQL_UPDATE = "UPDATE VEICULOTB SET marcaveiculo = ?, nomeveiculo = ? WHERE renavam = ?;";
	private String SQL_DELETE = "delete from VEICULOTB WHERE renavam = ?;";
	private String SQL_SELECT = "SELECT * FROM VEICULOTB;";
	
	public void inserir(Fornecedor f) {
		try {
			//Abrir conex�o
			conectar();
			
			//Inserir comando SQL de INSERT
			PreparedStatement ps = 
				db.getConnection().prepareStatement(SQL_INSERT);
			ps.setInt(1, f.getRenavam());
			ps.setString(2, f.getMarcaVeiculo());
			ps.setString(3, f.getNomeVeiculo());
			
			
			ps.executeUpdate();
			
			//Fechar conexao
			desconectar();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void alterar(Fornecedor f) {
		try {
			//Abrir conex�o
			conectar();
			
			//Inserir comando SQL de UPDATE
			PreparedStatement ps = 
				db.getConnection().prepareStatement(SQL_UPDATE);
			ps.setString(1, f.getMarcaVeiculo());
			ps.setString(2, f.getNomeVeiculo());
			ps.setInt(3, f.getRenavam());
			
			ps.executeUpdate();
			
			//Fechar conexao
			desconectar();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void excluir(Fornecedor f) {
		try {
			//Abrir conex�o
			conectar();
			
			//Inserir comando SQL de DELETE
			PreparedStatement ps = db.getConnection().prepareStatement(SQL_DELETE);
			ps.setInt(1, f.getRenavam());
			
			ps.executeUpdate();
			
			//Fechar conexao
			desconectar();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public List<Fornecedor> listarTodos(){
		List<Fornecedor> lista = new ArrayList<Fornecedor>();
		
		try {
			//Abrir conex�o
			conectar();
			
			//Inserir comando SQL de SELECT
			PreparedStatement ps = 
					db.getConnection().prepareStatement(SQL_SELECT);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				Fornecedor f = new Fornecedor(rs.getInt("renavam"), 
												rs.getString("marcaVeiculo"),
												rs.getString("nomeVeiculo"));
												
				
				lista.add(f);
			}
			
			
			//Fechar conexao
			desconectar();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lista;
	}

}
