package com.javabd.model;

public class Fornecedor {
	private int renavam;
	private String marcaVeiculo;
	private String nomeVeiculo;
		
	public Fornecedor(int renavam, String marcaVeiculo, String nomeVeiculo) {
		super();
		this.renavam = renavam;
		this.marcaVeiculo = marcaVeiculo;
		this.nomeVeiculo = nomeVeiculo;
		
	}

	public int getRenavam() {
		return renavam;
	}

	public void setRenavam(int renavam) {
		this.renavam = renavam;
	}

	public String getMarcaVeiculo() {
		return marcaVeiculo;
	}

	public void setMarcaVeiculo(String marcaVeiculo) {
		this.marcaVeiculo = marcaVeiculo;
	}

	public String getNomeVeiculo() {
		return nomeVeiculo;
	}

	public void setNomeVeiculo(String nomeVeiculo) {
		this.nomeVeiculo = nomeVeiculo;
	}

}
