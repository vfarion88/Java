package com.javabd.session;

import java.util.List;

import com.javabd.dao.FornecedorDAO;

import com.javabd.model.Fornecedor;

public class FornecedorSession {
	private FornecedorDAO dao;
	
	public FornecedorSession() {
		dao = new FornecedorDAO();
	}
	public void inserirFornecedor(Fornecedor f) {
		//Verificar se atributos foram informados
				
		//Verificar se um Fornecedor com o mesmo CNPJ j� existe
		//Implementar m�todo obterPorCnpj(int cnpj)
		
		//Chamar m�todo da DAO, se... Fornecedor n�o existir
		dao.inserir(f);
	}
	public List<Fornecedor> listarTodos() {
		//Verificar se atributos foram informados
				
		//Verificar se um Fornecedor com o mesmo CNPJ j� existe
		//Implementar m�todo obterPorCnpj(int cnpj)
		
		//Chamar m�todo da DAO, se... Fornecedor n�o existir
		return dao.listarTodos();
	}
	public void excluirFornecedor(int i) {
		
		Fornecedor f = new Fornecedor(i, "", "");
		
		dao.excluir(f);
	}
	public void alterarFornecedor(int i, String x,String y) {
		Fornecedor f = new Fornecedor(i,x,y);
		
		dao.alterar(f);
	}
}
